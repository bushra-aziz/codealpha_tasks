import { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Activities from './components/Activities';
import './styles/App.css';

function App() {
  const [currentView, setCurrentView] = useState('dashboard');
  const [fitnessData, setFitnessData] = useState({
    steps: 0,
    calories: 0,
    workouts: 0,
    distance: 0,
  });
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    (async () => {
      const savedData = localStorage.getItem('fitnessData');
      const savedActivities = localStorage.getItem('activities');

      if (savedData) {
        setFitnessData(JSON.parse(savedData));
      }

      if (savedActivities) {
        setActivities(JSON.parse(savedActivities));
      }
    })();
  }, []);

  const updateFitnessData = (data) => {
    setFitnessData(data);
    localStorage.setItem('fitnessData', JSON.stringify(data));
  };

  const addActivity = (activity) => {
    const newActivities = [...activities, { ...activity, id: Date.now(), date: new Date().toISOString() }];
    setActivities(newActivities);
    localStorage.setItem('activities', JSON.stringify(newActivities));

    const newData = {
      steps: fitnessData.steps + (activity.steps || 0),
      calories: fitnessData.calories + (activity.calories || 0),
      workouts: fitnessData.workouts + 1,
      distance: fitnessData.distance + (activity.distance || 0),
    };
    updateFitnessData(newData);
  };

  return (
    <div className="app">
      <Sidebar currentView={currentView} setCurrentView={setCurrentView} />
      <div className="main-content">
        {currentView === 'dashboard' && (
          <Dashboard
            fitnessData={fitnessData}
            activities={activities}
            updateFitnessData={updateFitnessData}
          />
        )}
        {currentView === 'activities' && (
          <Activities
            activities={activities}
            addActivity={addActivity}
          />
        )}
      </div>
    </div>
  );
}

export default App;
