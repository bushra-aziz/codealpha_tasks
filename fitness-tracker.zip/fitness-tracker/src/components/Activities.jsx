import { useState } from 'react';
import { Dumbbell, Bike, Footprints, Waves, Plus } from 'lucide-react';
import AddActivityModal from './AddActivityModal';

function Activities({ activities, addActivity }) {
  const [showModal, setShowModal] = useState(false);

  const getIcon = (type) => {
    switch(type?.toLowerCase()) {
      case 'running':
        return Footprints;
      case 'cycling':
        return Bike;
      case 'swimming':
        return Waves;
      default:
        return Dumbbell;
    }
  };

  const getColor = (type) => {
    switch(type?.toLowerCase()) {
      case 'running':
        return '#3b82f6';
      case 'cycling':
        return '#10b981';
      case 'swimming':
        return '#06b6d4';
      default:
        return '#8b5cf6';
    }
  };

  const handleAddActivity = (activity) => {
    addActivity(activity);
    setShowModal(false);
  };

  return (
    <div className="activities-page">
      <div className="dashboard-header">
        <div>
          <h1>All Activities</h1>
          <p className="subtitle">View and manage your fitness activities</p>
        </div>
        <button className="btn-primary" onClick={() => setShowModal(true)}>
          <Plus size={20} /> Add Activity
        </button>
      </div>

      <div className="activities-grid">
        {activities.length === 0 ? (
          <div className="empty-activities">
            <Dumbbell size={64} />
            <h3>No activities yet</h3>
            <p>Start tracking your fitness journey by adding your first activity</p>
            <button className="btn-primary" onClick={() => setShowModal(true)}>
              Add First Activity
            </button>
          </div>
        ) : (
          activities.slice().reverse().map((activity) => {
            const Icon = getIcon(activity.type);
            const color = getColor(activity.type);
            const date = new Date(activity.date);

            return (
              <div key={activity.id} className="activity-card">
                <div className="activity-card-header">
                  <div className="activity-icon-large" style={{ background: `${color}20`, color: color }}>
                    <Icon size={32} />
                  </div>
                  <div>
                    <h3>{activity.type}</h3>
                    <p className="activity-date">
                      {date.toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </p>
                  </div>
                </div>
                <div className="activity-card-stats">
                  <div className="stat-item">
                    <span className="stat-label">Duration</span>
                    <span className="stat-value">{activity.duration} min</span>
                  </div>
                  <div className="stat-item">
                    <span className="stat-label">Calories</span>
                    <span className="stat-value">{activity.calories} cal</span>
                  </div>
                  {activity.steps > 0 && (
                    <div className="stat-item">
                      <span className="stat-label">Steps</span>
                      <span className="stat-value">{activity.steps.toLocaleString()}</span>
                    </div>
                  )}
                  {activity.distance > 0 && (
                    <div className="stat-item">
                      <span className="stat-label">Distance</span>
                      <span className="stat-value">{activity.distance} km</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {showModal && (
        <AddActivityModal
          onClose={() => setShowModal(false)}
          onAdd={handleAddActivity}
        />
      )}
    </div>
  );
}

export default Activities;
