import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

function ActivityChart({ activities }) {
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    return date.toISOString().split('T')[0];
  });

  const chartData = last7Days.map(date => {
    const dayActivities = activities.filter(a =>
      a.date && a.date.split('T')[0] === date
    );

    const calories = dayActivities.reduce((sum, a) => sum + (a.calories || 0), 0);
    const steps = dayActivities.reduce((sum, a) => sum + (a.steps || 0), 0);

    return {
      date: new Date(date).toLocaleDateString('en-US', { weekday: 'short' }),
      calories,
      steps: Math.floor(steps / 100),
    };
  });

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="custom-tooltip">
          <p className="tooltip-label">{payload[0].payload.date}</p>
          <p className="tooltip-value" style={{ color: '#ec4899' }}>
            Calories: {payload[0].value}
          </p>
          {payload[1] && (
            <p className="tooltip-value" style={{ color: '#8b5cf6' }}>
              Steps: {payload[1].value * 100}
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="chart-card">
      <div className="chart-header">
        <h3>Weekly Activity</h3>
        <p className="chart-subtitle">Last 7 days performance</p>
      </div>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#2d3748" />
          <XAxis dataKey="date" stroke="#718096" />
          <YAxis stroke="#718096" />
          <Tooltip content={CustomTooltip} />
          <Line
            type="monotone"
            dataKey="calories"
            stroke="#ec4899"
            strokeWidth={3}
            dot={{ fill: '#ec4899', r: 4 }}
          />
          <Line
            type="monotone"
            dataKey="steps"
            stroke="#8b5cf6"
            strokeWidth={3}
            dot={{ fill: '#8b5cf6', r: 4 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default ActivityChart;
