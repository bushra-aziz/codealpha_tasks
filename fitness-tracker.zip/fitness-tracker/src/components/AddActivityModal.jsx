import { useState } from 'react';
import { X } from 'lucide-react';

function AddActivityModal({ onClose, onAdd }) {
  const [formData, setFormData] = useState({
    type: 'Running',
    duration: '',
    calories: '',
    steps: '',
    distance: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const activity = {
      type: formData.type,
      duration: parseInt(formData.duration) || 0,
      calories: parseInt(formData.calories) || 0,
      steps: parseInt(formData.steps) || 0,
      distance: parseFloat(formData.distance) || 0,
    };
    onAdd(activity);
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Add New Activity</h2>
          <button className="close-btn" onClick={onClose}>
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Activity Type</label>
            <select name="type" value={formData.type} onChange={handleChange}>
              <option value="Running">Running</option>
              <option value="Cycling">Cycling</option>
              <option value="Swimming">Swimming</option>
              <option value="Gym">Gym</option>
              <option value="Walking">Walking</option>
              <option value="Yoga">Yoga</option>
            </select>
          </div>

          <div className="form-group">
            <label>Duration (minutes)</label>
            <input
              type="number"
              name="duration"
              value={formData.duration}
              onChange={handleChange}
              placeholder="30"
              required
            />
          </div>

          <div className="form-group">
            <label>Calories Burned</label>
            <input
              type="number"
              name="calories"
              value={formData.calories}
              onChange={handleChange}
              placeholder="250"
              required
            />
          </div>

          <div className="form-group">
            <label>Steps (optional)</label>
            <input
              type="number"
              name="steps"
              value={formData.steps}
              onChange={handleChange}
              placeholder="5000"
            />
          </div>

          <div className="form-group">
            <label>Distance (km, optional)</label>
            <input
              type="number"
              step="0.1"
              name="distance"
              value={formData.distance}
              onChange={handleChange}
              placeholder="3.5"
            />
          </div>

          <div className="modal-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn-primary">
              Add Activity
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default AddActivityModal;
