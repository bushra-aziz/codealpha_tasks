import { useState } from 'react';
import StatsCard from './StatsCard';
import ActivityChart from './ActivityChart';
import QuickActions from './QuickActions';
import RecentActivities from './RecentActivities';
import AddActivityModal from './AddActivityModal';
import { Flame, Footprints, Dumbbell, MapPin } from 'lucide-react';

function Dashboard({ fitnessData, activities, updateFitnessData }) {
  const [showModal, setShowModal] = useState(false);

  const stats = [
    {
      title: 'Steps',
      value: fitnessData.steps.toLocaleString(),
      goal: '10,000',
      icon: Footprints,
      color: '#8b5cf6',
      progress: (fitnessData.steps / 10000) * 100
    },
    {
      title: 'Calories',
      value: fitnessData.calories.toLocaleString(),
      goal: '2,500',
      icon: Flame,
      color: '#ec4899',
      progress: (fitnessData.calories / 2500) * 100
    },
    {
      title: 'Workouts',
      value: fitnessData.workouts,
      goal: '5',
      icon: Dumbbell,
      color: '#3b82f6',
      progress: (fitnessData.workouts / 5) * 100
    },
    {
      title: 'Distance',
      value: `${fitnessData.distance.toFixed(1)} km`,
      goal: '5 km',
      icon: MapPin,
      color: '#10b981',
      progress: (fitnessData.distance / 5) * 100
    },
  ];

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <div>
          <h1>Dashboard</h1>
          <p className="subtitle">Track your daily fitness journey</p>
        </div>
        <button className="btn-primary" onClick={() => setShowModal(true)}>
          + Add Activity
        </button>
      </div>

      <div className="stats-grid">
        {stats.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      <div className="dashboard-grid">
        <ActivityChart activities={activities} />
        <RecentActivities activities={activities} />
      </div>

      <QuickActions />

      {showModal && (
        <AddActivityModal
          onClose={() => setShowModal(false)}
          onAdd={(activity) => {
            const newData = {
              steps: fitnessData.steps + (activity.steps || 0),
              calories: fitnessData.calories + (activity.calories || 0),
              workouts: fitnessData.workouts + 1,
              distance: fitnessData.distance + (activity.distance || 0),
            };
            updateFitnessData(newData);
            setShowModal(false);
          }}
        />
      )}
    </div>
  );
}

export default Dashboard;
