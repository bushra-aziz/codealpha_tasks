import { Dumbbell, Bike, Footprints, Waves } from 'lucide-react';

function QuickActions() {
  const actions = [
    { label: 'Strength Training', icon: Dumbbell, color: '#8b5cf6' },
    { label: 'Jogging/Running', icon: Footprints, color: '#3b82f6' },
    { label: 'Cycling', icon: Bike, color: '#10b981' },
    { label: 'Swimming', icon: Waves, color: '#06b6d4' },
  ];

  return (
    <div className="quick-actions">
      <h3>Quick Actions</h3>
      <div className="actions-grid">
        {actions.map((action, index) => (
          <button
            key={index}
            className="action-card"
            style={{ borderColor: action.color }}
          >
            <div className="action-icon" style={{ background: `${action.color}20`, color: action.color }}>
              <action.icon size={28} />
            </div>
            <span>{action.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export default QuickActions;
