import { Dumbbell, Bike, Footprints, Waves } from 'lucide-react';

function RecentActivities({ activities }) {
  const getIcon = (type) => {
    switch(type?.toLowerCase()) {
      case 'running':
        return Footprints;
      case 'cycling':
        return Bike;
      case 'swimming':
        return Waves;
      default:
        return Dumbbell;
    }
  };

  const getColor = (type) => {
    switch(type?.toLowerCase()) {
      case 'running':
        return '#3b82f6';
      case 'cycling':
        return '#10b981';
      case 'swimming':
        return '#06b6d4';
      default:
        return '#8b5cf6';
    }
  };

  const recentActivities = activities.slice(-5).reverse();

  return (
    <div className="recent-card">
      <div className="recent-header">
        <h3>Recent Activities</h3>
        <button className="view-all-btn">View All</button>
      </div>
      <div className="activities-list">
        {recentActivities.length === 0 ? (
          <p className="empty-state">No activities yet. Start tracking!</p>
        ) : (
          recentActivities.map((activity) => {
            const Icon = getIcon(activity.type);
            const color = getColor(activity.type);

            return (
              <div key={activity.id} className="activity-item">
                <div className="activity-icon" style={{ background: `${color}20`, color: color }}>
                  <Icon size={20} />
                </div>
                <div className="activity-details">
                  <h4>{activity.type}</h4>
                  <p>{activity.duration} min</p>
                </div>
                <div className="activity-stats">
                  <span className="activity-calories">{activity.calories} cal</span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

export default RecentActivities;
