import { Home, Activity, TrendingUp, Settings, User } from 'lucide-react';

function Sidebar({ currentView, setCurrentView }) {
  const menuItems = [
    { id: 'dashboard', icon: Home, label: 'Dashboard' },
    { id: 'activities', icon: Activity, label: 'Activities' },
    { id: 'progress', icon: TrendingUp, label: 'Progress' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-icon">
          <Activity size={24} />
        </div>
      </div>

      <nav className="sidebar-nav">
        {menuItems.map((item) => (
          <button
            key={item.id}
            className={`nav-item ${currentView === item.id ? 'active' : ''}`}
            onClick={() => setCurrentView(item.id)}
            title={item.label}
          >
            <item.icon size={20} />
          </button>
        ))}
      </nav>

      <div className="sidebar-bottom">
        <button className="nav-item" title="Settings">
          <Settings size={20} />
        </button>
      </div>
    </div>
  );
}

export default Sidebar;
