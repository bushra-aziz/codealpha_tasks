function StatsCard({ title, value, goal, icon: Icon, color, progress }) {
  const cappedProgress = Math.min(progress, 100);

  return (
    <div className="stats-card">
      <div className="stats-card-header">
        <div className="stats-icon" style={{ background: `${color}20`, color: color }}>
          <Icon size={24} />
        </div>
        <div className="stats-info">
          <p className="stats-title">{title}</p>
          <h2 className="stats-value">{value}</h2>
          <p className="stats-goal">Goal: {goal}</p>
        </div>
      </div>
      <div className="progress-bar">
        <div
          className="progress-fill"
          style={{ width: `${cappedProgress}%`, background: color }}
        ></div>
      </div>
      <p className="progress-text">{cappedProgress.toFixed(0)}% completed</p>
    </div>
  );
}

export default StatsCard;
