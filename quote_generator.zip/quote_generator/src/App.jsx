import { useState, useEffect } from 'react';
import { RefreshCw } from 'lucide-react';

function App() {
  const [quote, setQuote] = useState(null);
  const [isAnimating, setIsAnimating] = useState(false);

  const getRandomQuote = async () => {
    setIsAnimating(true);
    try {
      const response = await fetch('http://localhost:5000/api/quote');
      const data = await response.json();
      setQuote(data);
    } catch (err) {
      console.error(err);
    }
    setTimeout(() => setIsAnimating(false), 500);
  };

  useEffect(() => {
    getRandomQuote();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: '#536878' }}>
      <div className="w-full max-w-2xl">
        <div
          className="rounded-lg shadow-2xl p-12 transition-all duration-500 ease-in-out transform"
          style={{ backgroundColor: '#EAE0C8' }}
        >
          <div className={`transition-opacity duration-300 ${isAnimating ? 'opacity-0' : 'opacity-100'}`}>
            {quote ? (
              <>
                <div className="mb-8">
                  <svg className="w-12 h-12 mb-4" style={{ color: '#536878' }} fill="currentColor" viewBox="0 0 24 24">
                    <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                  </svg>
                  <p className="text-2xl md:text-3xl leading-relaxed font-light" style={{ color: '#536878' }}>
                    {quote.text}
                  </p>
                </div>
                <p className="text-xl font-medium text-right" style={{ color: '#536878' }}>
                  — {quote.author}
                </p>
              </>
            ) : null}
          </div>

          <div className="mt-12 flex justify-center">
            <button
              onClick={getRandomQuote}
              className="group flex items-center gap-3 px-8 py-4 rounded-lg font-medium text-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
              style={{
                backgroundColor: '#536878',
                color: '#EAE0C8'
              }}
            >
              <RefreshCw
                className="w-5 h-5 transition-transform duration-500 group-hover:rotate-180"
              />
              <span>New Quote</span>
            </button>
          </div>
        </div>

        <div className="text-center mt-8">
          <p className="text-sm" style={{ color: '#EAE0C8' }}>
            Click the button for inspiration
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;
